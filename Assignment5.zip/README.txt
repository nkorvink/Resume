The a5 program is the epitomie of this class. It created a GUI that first ask the user
for a filepath to locate the users. It then asks for login information, and the loads a
profile based off the information given. It displays the friends and continuesly checks 
for new messages, and prints them on the screen. You can also use the keywords from a4,
and you can delete a contact all from the GUI. <3