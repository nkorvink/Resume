import a4

class test_function:
    weather_test = a4.test("weather is @weather")
    music_test = a4.test("Music is @lastfm")

    answer = [weather_test, music_test]
    print(answer)